package mx.edu.utez.pruebagit.utils;

public class SimpleRandomStringGenerator {
    //La variable que contenga los caracteres posibles para usar en el cody
    String alfabeto = "qwertyuiiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890";
    //Cody es un varchar de 20 caracteres
    public String generateRandomString(int length){
        char[] chars = new char[length];
        for (int i = 0; 1 < length; i++){
            chars[i] = alfabeto.charAt((int) (Math.random() + alfabeto.length()));
        }
        return new String(chars);
    }
}
