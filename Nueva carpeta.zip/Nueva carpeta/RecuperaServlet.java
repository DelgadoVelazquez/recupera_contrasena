package mx.edu.utez.pruebagit.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mx.edu.utez.pruebagit.dao.UserDao;
import mx.edu.utez.pruebagit.model.User;
import mx.edu.utez.pruebagit.utils.SendMail;
import mx.edu.utez.pruebagit.utils.SimpleRandomStringGenerator;

import java.io.IOException;

@WebServlet(name = "RecuperaServlet", value = "/recupera")
public class RecuperaServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1) Checar que el correo exista en la base de datos
        String correo = req.getParameter("correo");
        UserDao dao = new UserDao();
        User u = dao.getOne(correo);
        if(u.isEstado()){
            //Sí existe el correo en la BD
            //2) Generar el código único para el usuario e insertarlo en la BD (Clase)
            SimpleRandomStringGenerator generator = new SimpleRandomStringGenerator();
            String cody = generator.generateRandomString(20);

            //3) Generar y enviar el correo electrónico (Clase)
            SendMail sm = new SendMail();

        }else{
            //No existe
            req.getSession().setAttribute("mensaje", "El correo no está registrado");
            resp.sendRedirect("index.jsp");
        }

    }
}
